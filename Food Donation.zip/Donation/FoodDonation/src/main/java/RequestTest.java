import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

@WebServlet("/Request")
public class RequestTest extends HttpServlet {
    static final long serialVersionUID = 1L;
     Connection con;
     Statement st;

    public RequestTest() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        response.setContentType("text/html");

        try {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.print("Driver Ok");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/database3", "root", "root");
            System.out.print("Connection Ok");

            st = con.createStatement();
            String sql = "select * from foodrequest";

            ResultSet rs = st.executeQuery(sql);

            out.print("<form action='RequestTest2'>");
            out.println("<table border='1'>");
            out.println("<tr><th>Food ID</th>");
            out.println("<th>Food Name</th><th>Quantity</th><th>Expire Date</th><th>Donator ID</th>");
            out.println("<th>Accept or Not</th>");

            while (rs.next()) {
                String foodID = rs.getString(1);
                String foodName = rs.getString(2);
                String foodQuantity = rs.getString(3);
                String foodDate = rs.getString(4);
                String donatorId = rs.getString(5);
                out.println("<tr><td>" + foodID + "</td>");
                out.println("<td>" + foodName + "</td>");
                out.println("<td>" + foodQuantity + "</td>");
                out.println("<td>" + foodDate + "</td>");
                out.println("<td>" + donatorId + "</td>");
                out.println("<td><input type=checkbox name=accept value="+foodID+">");
                out.println("</td></tr>");
            }
            
            
            out.print("<input type=\"submit\" name=\"buttonClicked\" value=\"Add\">");
            out.print("<input type=submit name=buttonClicked value=Delete>");
            out.print("</form>");
          

            st.close();
            con.close();
        } catch (Exception e) {
            out.print("Error");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

}