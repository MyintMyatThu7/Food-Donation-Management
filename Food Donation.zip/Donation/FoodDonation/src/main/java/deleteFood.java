

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

/**
 * Servlet implementation class phoneDeleteServlet
 */
public class deleteFood extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
    PreparedStatement pst;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public deleteFood() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		HttpSession session = request.getSession();
        String[] foodIds = (String[]) session.getAttribute("hello");
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.print("Driver Ok");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/database3", "root", "root");
			System.out.print("Connection Ok");
			
			String deleteModel = "delete from foodrequest where food_ID=?";
			pst = con.prepareStatement(deleteModel);
			
			for(int i = 0;i < foodIds.length;i++) {
			pst.setString(1, foodIds[i]); //index 1 delete where deleteModel = model
			pst.executeUpdate();
			out.print("correct");}
		}catch(Exception e) {
			out.print("Good Night");
		}
		request.getRequestDispatcher("AdminMain.jsp").forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
