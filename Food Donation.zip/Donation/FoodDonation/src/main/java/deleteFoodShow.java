

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * Servlet implementation class deleteFoodShow
 */
public class deleteFoodShow extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
	Statement st;
	PreparedStatement pst;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public deleteFoodShow() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());


		PrintWriter out = response.getWriter();
        response.setContentType("text/html");
        
        String id[] = request.getParameterValues("acceptId");
        HttpSession gg = request.getSession();
        gg.setAttribute("gg", id);
        
        HttpSession sio = request.getSession();
        String uid = (String) sio.getAttribute("useridd");
       
        try {
        	Class.forName("com.mysql.jdbc.Driver");
        	
        	con = DriverManager.getConnection("jdbc:mysql://localhost:3306/database3","root","root");
        	
        	
        	String s = "insert into customerfood values(?,?,?,?,?,?)";
        	try(PreparedStatement pst = con.prepareStatement(s)) {
        		for(int i = 0; i < id.length; i++) {
        			st = con.createStatement();
        			String sql = "select * from foodshow where FoodID='"+ id[i]+"'";
        			ResultSet rs = st.executeQuery(sql);
        			
        			while(rs.next()) {
        				String foodID = rs.getString(1);
        				String foodName = rs.getString(2);
        				String foodQuantity = rs.getString(3);
        				String foodDate = rs.getString(4);
        				String donatorId = rs.getString(5);
        				String addd = rs.getString(6);
        				
//        				HttpSession hh = request.getSession();
//        				hh.setAttribute("f_id", foodID);
//        				hh.setAttribute("d_id", donatorId);
        				pst.setString(1, foodID);  //column 1
             			pst.setString(2, foodName);
              			
              			pst.setString(3, foodQuantity);
             			pst.setString(4,foodDate);
              			pst.setString(5,donatorId);
              			pst.setString(6,addd);
              			
              			pst.executeUpdate();
        			}
        		}
        		out.print("<html><head>"
        				+ " <meta charset=\"UTF-8\">\r\n"
        				+ "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n"
        				+ "   <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\r\n"
        				+ "\r\n"
        				+ "    <link rel=\"preconnect\" href=\"https://fonts.googleapis.com\">\r\n"
        				+ "<link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin>\r\n"
        				+ "<link href=\"https://fonts.googleapis.com/css2?family=ADLaM+Display&family=Alumni+Sans+Inline+One:ital@1&family=Archivo+Black&family=Bowlby+One&family=Fira+Code:wght@300..700&family=Hind+Siliguri:wght@700&family=Poppins:wght@400;500;600;700&family=Roboto:wght@900&family=Rubik+Burned&family=Rubik+Glitch&family=Source+Sans+3:wght@900&family=Tektur:wght@400;500;600;700;800&family=Ultra&family=Work+Sans:wght@300;400;500;600;800;900&display=swap\" rel=\"stylesheet\">\r\n"
        				+ "<script type=\"module\" src=\"https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js\"></script>\r\n"
        				+ "<script nomodule src=\"https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js\"></script>\r\n"
        				+ "<link rel=\"preconnect\" href=\"https://fonts.googleapis.com\">\r\n"
        				+ "<link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin>\r\n"
        				+ "<link href=\"https://fonts.googleapis.com/css2?family=Lemon&display=swap\" rel=\"stylesheet\">\r\n"
        				+ "  <title>Document</title><style>"
        				+ ".warpper-new-a{\r\n"
        				+ "    \r\n"
        				+ "    position: fixed;\r\n"
        				+ "    width: 300px;\r\n"
        				+ "    height: 390px;\r\n"
        				+ "    background: transparent;\r\n"
        				+ "    border: 2px solid rgba(255,255,255,.5);\r\n"
        				+ "    border-radius: 20px;\r\n"
        				+ "    backdrop-filter: blur(20px);\r\n"
        				+ "    box-shadow: 0 0 30px rgba(0,0,0,.5);\r\n"
        				+ "    display: none;\r\n"
        				+ "    justify-content: center;\r\n"
        				+ "    align-items: center;\r\n"
        				+ "    overflow: hidden; \r\n"
        				+ "    transition: transform .5s ease, height .2s ease;\r\n"
        				+ "    top: 7em;\r\n"
        				+ "    margin-left: 35.5em;\r\n"
        				+ "    z-index: 7;\r\n"
        				+ "}\r\n"
        				+ "\r\n"
        				+ ".warpper-new-a.form-box-new-a{\r\n"
        				+ "    width: 100%;\r\n"
        				+ "    padding: 40px;\r\n"
        				+ "}\r\n"
        				+ "\r\n"
        				+ " .warpper-new-a .form-box-new-a.login{\r\n"
        				+ "    transition: transform .2s ease;\r\n"
        				+ "    transform: translateX(0);\r\n"
        				+ "}\r\n"
        				+ "\r\n"
        				+ "/* right back--------------- */\r\n"
        				+ "\r\n"
        				+ "/* .warpper-new .form-box-new.register{\r\n"
        				+ "    position: absolute;\r\n"
        				+ "     transition: none; \r\n"
        				+ "    transform: translateX(400px);\r\n"
        				+ "} */\r\n"
        				+ "\r\n"
        				+ "\r\n"
        				+ ".warpper-new-a .icon-close{\r\n"
        				+ "    position: absolute;\r\n"
        				+ "    top: 0;\r\n"
        				+ "    right: 0;\r\n"
        				+ "    width: 40px;\r\n"
        				+ "    height: 40px;\r\n"
        				+ "    background: rgb(255, 155, 6);\r\n"
        				+ "    font-size: 1.6em;\r\n"
        				+ "    color: rgb(0, 0, 0);\r\n"
        				+ "    display: flex;\r\n"
        				+ "    justify-content: center;\r\n"
        				+ "    align-items: center;\r\n"
        				+ "    border-bottom-left-radius: 20px;\r\n"
        				+ "    cursor: pointer;\r\n"
        				+ "    z-index: 1;\r\n"
        				+ "}\r\n"
        				+ "\r\n"
        				+ ".form-box-new-a h2{\r\n"
        				+ "    font-size: 1em;\r\n"
        				+ "    color: #162938;\r\n"
        				+ "    text-align: center;\r\n"
        				+ "}\r\n"
        				+ "\r\n"
        				+ "/* for Login ----------------------------------------*/\r\n"
        				+ ".input-box-new-a{\r\n"
        				+ "    position: relative;\r\n"
        				+ "    width: 100%;\r\n"
        				+ "    height: 50px;\r\n"
        				+ "    border-bottom: 2px solid #162938;\r\n"
        				+ "    margin: 20px 0;\r\n"
        				+ "}\r\n"
        				+ "\r\n"
        				+ ".input-box-new-a label{\r\n"
        				+ "    position: absolute;\r\n"
        				+ "    top: 50%;\r\n"
        				+ "    left: 5px;\r\n"
        				+ "    transform: translateY(-50%);\r\n"
        				+ "    font-size: 1em;\r\n"
        				+ "    color: #162938;\r\n"
        				+ "    font-weight: 500;\r\n"
        				+ "    pointer-events: none;\r\n"
        				+ "     transition: .5s;\r\n"
        				+ "}\r\n"
        				+ ".input-box-new-a input:focus~label,\r\n"
        				+ ".input-box-new-a input:valid~label{\r\n"
        				+ "    top: -5px;\r\n"
        				+ "}\r\n"
        				+ ".input-box-new-a input{\r\n"
        				+ "    width: 100%;\r\n"
        				+ "    height: 100%;\r\n"
        				+ "    background: transparent;\r\n"
        				+ "    border: none;\r\n"
        				+ "    outline: none;\r\n"
        				+ "     font-size: 1em;\r\n"
        				+ "    color: #162938;\r\n"
        				+ "    font-weight: 600;\r\n"
        				+ "    padding: 0 35px 0 5px; \r\n"
        				+ "}\r\n"
        				+ "\r\n"
        				+ "\r\n"
        				+ ".btn-new{\r\n"
        				+ "    width: 100%;\r\n"
        				+ "    height: 45px;\r\n"
        				+ "    background: rgb(255, 155, 6);\r\n"
        				+ "    border: none;\r\n"
        				+ "    border-radius: 6px;\r\n"
        				+ "    cursor: pointer;\r\n"
        				+ "    font-size: 1em;\r\n"
        				+ "    color: #162938;\r\n"
        				+ "    font-weight: 600;\r\n"
        				+ "    outline: none;\r\n"
        				+ "}\r\n"
        				+ ".form-box-new .btn-new:hover{\r\n"
        				+ "    background: rgb(255, 64, 6);\r\n"
        				+ "    transition: 1s;\r\n"
        				+ "}\r\n"
        				+ ".input-box-new-a p{\r\n"
        				+ "    font-size: 9px;\r\n"
        				+ "    font-weight: 600;\r\n"
        				+ "    margin-left: 25px;\r\n"
        				+ "}"
        				+ ".warpper-new{\r\n"
        				+ "    justify-content: center;\r\n"
        				+ "   align-items: center;\r\n"
        				+ "    position: fixed;\r\n"
        				+ "    width: 350px;\r\n"
        				+ "    height: 290px;\r\n"
        				+ "    background: transparent;\r\n"
        				+ "    border: 2px solid rgb(255, 155, 6);\r\n"
        				+ "    border-radius: 20px;\r\n"
        				+ "    backdrop-filter: blur(20px);\r\n"
        				+ "    background-color: #fff8dc;\r\n"
        				+ "    box-shadow: 0 0 30px rgba(0,0,0,.5);\r\n"
        				
        				+ "    justify-content: center;\r\n"
        				+ "    align-items: center;\r\n"
        				+ "    overflow: hidden; \r\n"
        				+ "    /* transform: scale(0);  */\r\n"
        				+ "    transition: transform .5s ease, height .2s ease;\r\n"
        				+ "   top: 100px;\r\n"
        				+ "     margin-left: 32em;\r\n"
        				+ "     z-index: 5;\r\n"
        				+ "}\r\n"
        				+ "/* .warpper-new.active-popup{\r\n"
        				+ "    transform: scale(1);\r\n"
        				+ "\r\n"
        				+ "}   */\r\n"
        				+ "\r\n"
        				+ "\r\n"
        				+ ".warpper-new.form-box-new{\r\n"
        				+ "    width: 100%;\r\n"
        				+ "    padding: 40px;\r\n"
        				+ "}\r\n"
        				+ "\r\n"
        				+ " .warpper-new .form-box-new.login{\r\n"
        				+ "    transition: transform .2s ease;\r\n"
        				+ "    transform: translateX(0);\r\n"
        				+ "}\r\n"
        				+ "\r\n"
        				+ "/* right back--------------- */\r\n"
        				+ "\r\n"
        				+ "/* .warpper-new .form-box-new.register{\r\n"
        				+ "    position: absolute;\r\n"
        				+ "     transition: none; \r\n"
        				+ "    transform: translateX(400px);\r\n"
        				+ "} */\r\n"
        				+ "\r\n"
        				+ "\r\n"
        				+ ".warpper-new .icon-close{\r\n"
        				+ "    position: absolute;\r\n"
        				+ "    top: 0;\r\n"
        				+ "    right: 0;\r\n"
        				+ "    width: 40px;\r\n"
        				+ "    height: 40px;\r\n"
        				+ "    background: rgb(255, 155, 6);\r\n"
        				+ "    font-size: 1.6em;\r\n"
        				+ "    color: rgb(0, 0, 0);\r\n"
        				+ "    display: flex;\r\n"
        				+ "    justify-content: center;\r\n"
        				+ "    align-items: center;\r\n"
        				+ "    border-bottom-left-radius: 20px;\r\n"
        				+ "    cursor: pointer;\r\n"
        				+ "    z-index: 1;\r\n"
        				+ "}\r\n"
        				+ "\r\n"
        				+ ".form-box-new h2{\r\n"
        				+ "    font-size: 1em;\r\n"
        				+ "    color: #162938;\r\n"
        				+ "    text-align: center;\r\n"
        				+ "}\r\n"
        				+ "\r\n"
        				+ "\r\n"
        				+ ".btn-new{\r\n"
        				+ "    width: 100%;\r\n"
        				+ "    height: 45px;\r\n"
        				+ "    background: rgb(255, 155, 6);\r\n"
        				+ "    border: none;\r\n"
        				+ "    border-radius: 6px;\r\n"
        				+ "    cursor: pointer;\r\n"
        				+ "    font-size: 1em;\r\n"
        				+ "    color: #162938;\r\n"
        				+ "    font-weight: 600;\r\n"
        				+ "    outline: none;\r\n"
        				+ "}\r\n"
        				+ ".form-box-new .btn-new:hover{\r\n"
        				+ "    background: rgb(255, 64, 6);\r\n"
        				+ "    transition: 1s;\r\n"
        				+ "}\r\n"
        				+ ".form-box-new  img{\r\n"
        				+ "  \r\n"
        				+ "justify-content: space-between;\r\n"
        				+ "    height: 130px;\r\n"
        				+ "    width: 130px;\r\n"
        				+ "    border-radius: 100px;\r\n"
        				+ "    margin: 50px 18px;\r\n"
        				+ "   \r\n"
        				+ "  \r\n"
        				+ "}\r\n"
        				+ "\r\n"
        				+ " \r\n"
        				+ ".ok {\r\n"
        				+ "    display: flex;\r\n"
        				+ "}\r\n"
        				+ ".ok input{\r\n"
        				+ "    \r\n"
        				+ "    display: block;\r\n"
        				+ "    margin-left: 50px;\r\n"
        				+ "    border: 1px solid #162938;\r\n"
        				+ "    border-radius: 7px;\r\n"
        				+ "    height: 30px;\r\n"
        				+ "    width: 100px;\r\n"
        				+ "    background-color: rgb(255, 155, 6);\r\n"
        				+ "    top: 100px;\r\n"
        				+ "    transition: .5s;\r\n"
        				+ "}\r\n"
        				+ "\r\n"
        				+ ".ok input:hover{\r\n"
        				+ "    background-color: #00bb00;\r\n"
        				+ "}\r\n"
        				+ "  \r\n"
        				+ "    *{\r\n"
        				+ "   margin: 0;\r\n"
        				+ "   padding: 0;\r\n"
        				+ "   box-sizing: border-box;\r\n"
        				+ "   font-family: \"poppins\",sans-serif;\r\n"
        				+ "}\r\n"
        				+ "\r\n"
        				+ "body{\r\n"
        				+ "    display: flex;\r\n"
        				+ "    align-items: center;\r\n"
        				+ "    min-height: 100vh;\r\n"
        				+ "    background: url('main.jpg') no-repeat;\r\n"
        				+ "    background-size: cover;\r\n"
        				+ "    background-position: center;\r\n"
        				+ "    background-attachment: fixed;\r\n"
        				+ "}\r\n"
        				+ "\r\n"
        				+ "header{\r\n"
        				+ "    position: fixed;\r\n"
        				+ "    top: 0;\r\n"
        				+ "    left: 0;\r\n"
        				+ "    width: 100%;\r\n"
        				+ "    background: rgba(255, 155, 6, 0.24);\r\n"
        				+ "    padding: 20px 100px;\r\n"
        				+ "    display: flex;\r\n"
        				+ "    justify-content: space-between;\r\n"
        				+ "    align-items: center;\r\n"
        				+ "    z-index: 99;\r\n"
        				+ "    height: 60px;\r\n"
        				+ "}\r\n"
        				+ "\r\n"
        				+ ".logo{\r\n"
        				+ "    font-size: 2rem;\r\n"
        				+ "    \r\n"
        				+ "    user-select: none;\r\n"
        				+ "    font-family: cursive;\r\n"
        				+ "    color: rgb(255, 0, 0);\r\n"
        				+ "\r\n"
        				+ "}\r\n"
        				+ ".navigation a{\r\n"
        				+ "    position: relative;\r\n"
        				+ "    font-size: 1.1em;\r\n"
        				+ "    color: rgb(255, 255, 255);\r\n"
        				+ "    text-decoration: none;\r\n"
        				+ "    font-weight: 500;\r\n"
        				+ "    margin-left: 40px;\r\n"
        				+ "}\r\n"
        				+ "\r\n"
        				+ ".navigation a::after{\r\n"
        				+ "    content: '';\r\n"
        				+ "    left: 0;\r\n"
        				+ "    bottom: -6px;\r\n"
        				+ "    position: absolute;\r\n"
        				+ "    width: 100%;\r\n"
        				+ "    height: 3px;\r\n"
        				+ "    background: #fff;\r\n"
        				+ "    border-radius: 5px;\r\n"
        				+ "    transform-origin: left;\r\n"
        				+ "    transform: scaleX(0);\r\n"
        				+ "    transition: transform .5s;\r\n"
        				+ "}\r\n"
        				+ ".navigation a:hover:after{\r\n"
        				+ "    transform-origin: right;\r\n"
        				+ "    transform: scaleX(1);\r\n"
        				+ "}\r\n"
        				+ "\r\n"
        				+ ".navigation .btnLogin-popup{\r\n"
        				+ "    width: 120px;\r\n"
        				+ "    height: 40px;\r\n"
        				+ "    background: transparent;\r\n"
        				+ "    border: 2px solid rgba(255, 255, 255, 0.76);\r\n"
        				+ "    outline: none;\r\n"
        				+ "    border-radius: 6px;\r\n"
        				+ "    cursor: pointer;\r\n"
        				+ "    font-size: 1.1em;\r\n"
        				+ "    color: rgb(255, 255, 255);\r\n"
        				+ "    font-weight: 500;\r\n"
        				+ "    margin-left: 40px;\r\n"
        				+ "    transition: .5s;\r\n"
        				+ "}\r\n"
        				+ ".navigation .btnLogin-popup:hover{\r\n"
        				+ "    background: rgb(255, 155, 6);\r\n"
        				+ "    color: #162938;\r\n"
        				+ "}"
        				+ "     .navigation img{\r\n"
        				+ "    left: 13em;\r\n"
        				+ "   top: 5px;\r\n"
        				+ "    position: absolute;\r\n"
        				+ " border-radius: 150px;\r\n"
        				+ " width:50px;height:50px; \r\n"
        				+ " background-repeat: no-repeat;\r\n"
        				+ " background-size: cover;\r\n"
        				+ "}\r\n"
        				+ " .navigation span{               \r\n"
        				+ "    margin-top: 7px;\r\n"
        				+ "position: absolute;\r\n"
        				+ " left: 13.5em;\r\n"
        				+ " font-size: 15px;\r\n"
        				+ " color: #1f1d1d;\r\n"
        				+ " font-weight: 500;\r\n"
        				+ "\r\n"
        				+ " }\r\n"
        				+ "  .navigation .mgmg span{\r\n"
        				+ "  position: absolute;\r\n"
        				+ "   text-align: center;\r\n"
        				+ "    height: 27px;\r\n"
        				+ "border-radius: 20px;\r\n"
        				+ "    width: 120px;\r\n"
        				+ "    margin-left:65px;\r\n"
        				+ "    background-color: rgb(255, 255, 255);\r\n"
        				+ "}\r\n"
        				+ "</style></head><body>"
        				+ " <header>\r\n"
        				+ "    <h2 class=\"logo\">MMN</h2>\r\n"
        				+ "    <nav class=\"navigation\">\r\n"
        				
        				+ "       		<img src=\"pro.png\"><div class=\"mgmg\"><span>ID : "+uid+"</span></div>"
        				+ "        <a href=\"#\">About</a>\r\n"
        				+ "        <a href=\"#\">Contact</a>\r\n"
        				+ "        <a href=\"#\">Find Food Here</a>\r\n"
        				+ "        <button class=\"btnLogin-popup\" onclick=\"window.location.href='mainlogin.jsp'\">Logout</button>\r\n"
        				+ "    </nav>\r\n"
        				+ "</header><div class=\"warpper-new\" id=\"aa\">\r\n"
        				+ "    <span class=\"icon-close\" onclick=\"back()\" id=\"back\">\r\n"
        				+ "        <ion-icon name=\"close\"></ion-icon>\r\n"
        				+ "    </span>\r\n"
        				+ "\r\n"
        				+ "    <div class=\"form-box-new login\">\r\n"
        				+ "       <img src=\"in.png\">\r\n"
        				+ "        <img src=\"delivery.png\">\r\n"
        				+ "</div>\r\n"
        				+ "        <div class=\"ok\">\r\n"
        				+ "          \r\n"
        				
        				+ "        <input type=\"submit\" value=\"Delivery\" onclick=\"go()\">\r\n"
        	
        				+ "        \r\n"
        				+ "                    		 <form action=\"deletefoodShowBefore2\">\r\n"
        				+ "                    		<input type=\"submit\" value=\"Get it by myself\">\r\n"
        				+ "                    		</form> \r\n"
        				+ "                          \r\n"
        				+ "    </div>\r\n"
        				+ "    </div>"
        				+ " <div class=\"warpper-new-a\" id=\"inn\">\r\n"
        				+ "    <span class=\"icon-close\" >\r\n"
        				+ "        <ion-icon name=\"close\" onclick=\"backA()\"></ion-icon>\r\n"
        				+ "    </span>\r\n"
        				+ "    <div class=\"form-box-new-a login\">\r\n"
        				+ "  <h2>Door To Door</h2>\r\n"
        				+ "        <form action=\"deletefoodShowBefore\">\r\n"
        				+ "            <div class=\"input-box-new-a\">\r\n"
        				+ "               \r\n"
        				+ "                <input type=\"text\" required name=\"userName\">\r\n"
        				+ "                <label>Name</label>\r\n"
        				+ "            </div>\r\n"
        				+ "         \r\n"
        				+ "            <div class=\"input-box-new-a\">\r\n"
        				+ "            \r\n"
        				+ "                <input type=\"text\" required name=\"userPhone\" pattern=\"[0]{1}[9]{1}[0-9]{7,9}\">\r\n"
        				+ "                <label>Phone Number</label>\r\n"
        				+ "            </div>\r\n"
        				+ "            <div class=\"input-box-new-a\">\r\n"
        				+ "                \r\n"
        				+ "                <input type=\"text\" required name=\"userAddress\">\r\n"
        				+ "                <label>Address</label>\r\n"
        				+ "            </div>"
        			
        				+ "            <button type=\"submit\" class=\"btn-new\">Submit</button>\r\n"
        				+ "        </form>\r\n"
        				+ "            \r\n"
        				+ "    </div>\r\n"
        				+ " </div>"
        				+ "        </body>"
        				+ "<script>\r\n"
        				+ "function back(){\r\n"
        				+ "    window.location.href=\"DonatedFoodList.jsp\"\r\n"
        				+ "}\r\n"
        				+ "function go(){\r\n"
        				+ "    document.getElementById(\"aa\").style.display=\"none\";\r\n"
        				+ "    document.getElementById(\"inn\").style.display=\"flex\";\r\n"
        				+ "}\r\n"
        				+ "function backA(){\r\n"
        				+ "    document.getElementById(\"inn\").style.display=\"none\";\r\n"
        				+ "    document.getElementById(\"aa\").style.display=\"block\";\r\n"
        				+ "}\r\n"
        				+ "</script>"
        				+ "<script type=\"module\" src=\"https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js\"></script>\r\n"
        				+ "<script nomodule src=\"https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js\"></script></html>");
        		
        	}catch(Exception  e) {
        		out.print("customerFood error");
        	}
        	

        }catch(Exception e) {
        	out.print("Out side error");
        }
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
