

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
/**
 * Servlet implementation class deliveryServlet
 */
public class deliveryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
    PreparedStatement pst;
    boolean result=false;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public deliveryServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		String employeeID = "EE-";
		String empname=request.getParameter("name");
		String empphno=request.getParameter("phone");
		String empaddress=request.getParameter("address");
		
		int emp_id = 1;
		Cookie ck[] = request.getCookies();
		
		if(ck != null) {
			
			for(Cookie c:ck) {
				
				if(c.getName().equals("student")) {
					emp_id = Integer.parseInt(c.getValue()) + 1;
				}
			}
		Cookie cus = new Cookie("student",Integer.toString(emp_id));
		cus.setMaxAge(3600);
		response.addCookie(cus);
		employeeID += emp_id;
		}
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.print("Driver Ok");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/database3","root","root");
			System.out.print("Connection OK");
			String s="insert into employee values(?,?,?,?)";
			pst=con.prepareStatement(s);
			pst.setString(1, employeeID);
			pst.setString(2, empname);
			pst.setString(3, empphno);
			pst.setString(4, empaddress);
	
			pst.executeUpdate();
		
			request.getRequestDispatcher("AdminMain.jsp").include(request, response);
			out.print("<html><body><script>alert('Insert Succefully!!')</script></body></html>");
			
		}
			catch(Exception e) {
				out.print("Something Error");
			}
		}

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
