import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

@WebServlet("/addFoodTest")
public class addFoodTest extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private Connection con;
    private PreparedStatement pst;
    private Statement st;

    public addFoodTest() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

      
        HttpSession session = request.getSession();
        String[] foodIds = (String[]) session.getAttribute("hello");
        

        try {
        // Null check before using foodIds
        Class.forName("com.mysql.jdbc.Driver");
        System.out.print("Driver Ok");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/database3", "root", "root");
        System.out.print("Connection Ok");
        
        
        String s = "insert into foodmain values(?,?,?,?,?,?)";
        try (PreparedStatement pst = con.prepareStatement(s)){
        	for(int i = 0 ;i < foodIds.length;i++) {
        		st = con.createStatement();
              String sql = "select * from foodrequest where food_ID='"+ foodIds[i]+"'";

             ResultSet rs = st.executeQuery(sql);

              while (rs.next()) {
                  String foodID = rs.getString(1);
                String foodName = rs.getString(2);
                  String foodQuantity = rs.getString(3);
                 String foodDate = rs.getString(4);
                 String donatorId = rs.getString(5);
                 String addre = rs.getString(6);
     			
     			pst.setString(1, foodID);  //column 1
     			pst.setString(2, foodName);
      			
      			pst.setString(3, foodQuantity);
     			pst.setString(4,foodDate);
      			pst.setString(5,donatorId);
      			pst.setString(6,addre);
     			
      			
    			pst.executeUpdate();
              }
        	}
        }catch(Exception e) {
        	out.print("foodmain error");
        }
        
        
        
        
        String str = "insert into foodshow values(?,?,?,?,?,?)";
        try (PreparedStatement pom = con.prepareStatement(str)){
        	for(int i = 0 ;i < foodIds.length;i++) {
        		st = con.createStatement();
              String sql = "select * from foodrequest where food_ID='"+ foodIds[i]+"'";

             ResultSet rs = st.executeQuery(sql);

              while (rs.next()) {
                  String foodID = rs.getString(1);
                String foodName = rs.getString(2);
                  String foodQuantity = rs.getString(3);
                 String foodDate = rs.getString(4);
                 String donatorId = rs.getString(5);
                 String add = rs.getString(6);
                 
     			
     			pom.setString(1, foodID);  //column 1
     			pom.setString(2, foodName);
      			
      			pom.setString(3, foodQuantity);
     			pom.setString(4,foodDate);
      			pom.setString(5,donatorId);
      			pom.setString(6,add);
     			
      			
    			pom.executeUpdate();
              }
        	}
        }catch(Exception e) {
        	out.print("foodshow error");
        }
        
        
        

        request.getRequestDispatcher("deleteFood").forward(request, response);

   } catch (Exception e) {
        out.print("Error");
    }
        
}

protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    doGet(request, response);
}

}