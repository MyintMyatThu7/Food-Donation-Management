import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/FoodUploadServlert")
public class FoodUploadServlert extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private Connection con;
    private PreparedStatement pst;

    public FoodUploadServlert() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        response.setContentType("text/html");

        String food = request.getParameter("foodID");
        String fname = request.getParameter("foodname");
        String fqty = request.getParameter("foodqty");
        String fdate = request.getParameter("fooddate");
        String did = request.getParameter("did");
        String address = request.getParameter("address");
        HttpSession st = request.getSession();
        st.setAttribute("did", did);
        
//        String userID = "User ";
//        String EmailUser = request.getParameter("name");
//        String Phone = request.getParameter("phone");
//        String Address = request.getParameter("address");
        //String DonatorID = "b1";

//        int cus_id = 1;
//        Cookie ck[] = request.getCookies();
//        String userID1 = "Food ";
//        if (ck != null) {
//            for (Cookie c : ck) {
//                if (c.getName().equals("studen")) {
//                    cus_id = Integer.parseInt(c.getValue()) + 1;
//                }
//            }
//            Cookie cus = new Cookie("studen", Integer.toString(cus_id));
//            cus.setMaxAge(36000);
//            response.addCookie(cus);
//            userID1 += cus_id;
   //     }
        
        try {
        	Class.forName("com.mysql.jdbc.Driver");
            System.out.print("Driver Ok");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/database3", "root", "root");
            System.out.print("Connection Ok");
            
            String s = "insert into foodrequest values(?,?,?,?,?,?)";
    		pst = con.prepareStatement(s);

    		pst.setString(1,food);  //column 1
			pst.setString(2, fname);
			
			pst.setString(3, fqty);
			pst.setString(4,fdate);
			pst.setString(5,did);
			pst.setString(6,address);
			
			request.getRequestDispatcher("DonaterMain.jsp").forward(request, response);
			pst.executeUpdate();

            
            
        } catch (Exception e) {
        	out.print("Error");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    } 
}