

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * Servlet implementation class LoginCheckDataBaseServlet
 */
public class SignInEmployeeCheckDatabase extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	boolean result = false;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SignInEmployeeCheckDatabase() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String name = request.getParameter("id");
		String phone = request.getParameter("phone");
		result = false;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.print("Driver Ok");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/database3","root","root");
			System.out.print("Connection OK");
			
		    String s = "select ('employee_iD,employee_phone') from employee where employee_iD='"+name+"' and employee_phone='"+phone+"'";
		    pst = con.prepareStatement(s);
		    rs = pst.executeQuery();
		    while(rs.next()) {//to read step by step use next
		    	result = true;
		    }
		    pst.close();
		    con.close();
		}catch(Exception e) {
			out.print(e);
		}
		if(result) {
			request.getRequestDispatcher("DeliveryMain.jsp").forward(request, response);
		}else {
			request.getRequestDispatcher("Employerlogin.jsp").include(request, response);
			out.print("<html><body><script>alert('Uncorrect password.Please Tty again!')</script></body></html>");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
