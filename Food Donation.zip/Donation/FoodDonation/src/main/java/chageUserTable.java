

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * Servlet implementation class chageUserTable
 */
@WebServlet("/chageUserTable")
public class chageUserTable extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Database connection parameters
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/database3";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "root";

    /**
     * @see HttpServlet#HttpServlet()
     */
    public chageUserTable() {
        super();
    }

    /**
     * Establishes a database connection.
     */
    private Connection connectDatabase() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD);
    }

    /**
     * Closes the database connection and statement.
     */
    private void closeDatabase(Connection con, Statement st) {
        try {
            if (st != null) {
                st.close();
            }
            if (con != null) {
                con.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Get session and parameter values
        
        String[] foodID = request.getParameterValues("accept");
        HttpSession s = request.getSession();
        s.setAttribute("idFood",foodID);
        // Establish database connection
        try (Connection con = connectDatabase()) {
            String sql = "INSERT INTO deliveryuserchange VALUES(?,?,?,?,?,?,?,?,?)";

            try (PreparedStatement pst = con.prepareStatement(sql)) {
                // Loop through selected food IDs
                for (String id : foodID) {
                    try (Statement st = con.createStatement()) {
                        String selectSql = "SELECT * FROM deliveryuser WHERE f_id='" + id + "'";
                        ResultSet rs = st.executeQuery(selectSql);

                        while (rs.next()) {
                            // Retrieve data from the result set
                            String userId = rs.getString(1);
                            String userName = rs.getString(2);
                            String userPhone = rs.getString(3);
                            String userAddress = rs.getString(4);
                            String foodId = rs.getString(5);
                            String foodName = rs.getString(6);
                            String foodQuantity = rs.getString(7);
                            String foodDate = rs.getString(8);
                            String donatorId = rs.getString(9);

                            // Set values in the prepared statement
                            pst.setString(1, userId);
                            pst.setString(2, userName);
                            pst.setString(3, userPhone);
                            pst.setString(4, userAddress);
                            pst.setString(5, foodId);
                            pst.setString(6, foodName);
                            pst.setString(7, foodQuantity);
                            pst.setString(8, foodDate);
                            pst.setString(9, donatorId);

                            // Execute the update
                            pst.executeUpdate();
                        }
                    }
                }

                request.getRequestDispatcher("chageUserTableDelete").forward(request, response);
            } catch (Exception e) {
                e.printStackTrace();
                out.print("An error occurred while processing your request. Please try again later.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            out.print("An error occurred while establishing a database connection.");
        }
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}