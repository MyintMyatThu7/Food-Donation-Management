import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

@WebServlet("/lookWhotoacceptdelivery2")
public class lookWhotoacceptdelivery2 extends HttpServlet {
    private static final long serialVersionUID = 1L;
    Connection con;
    PreparedStatement pst;

    public lookWhotoacceptdelivery2() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String[] idFood = request.getParameterValues("a");

        try {
            if (idFood != null && idFood.length > 0) {
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/database3", "root", "root");

                String deleteModel = "DELETE FROM deliveryuserchange WHERE food_id=?";
                pst = con.prepareStatement(deleteModel);

                for (String id : idFood) {
                    pst.setString(1, id);
                    pst.executeUpdate();
                }

                request.getRequestDispatcher("DeliveryMain.jsp").forward(request, response);
            } else {
                out.print("No records selected for deletion.");
            }
        } catch (Exception e) {
            out.print("An error occurred while processing your request. Please try again later.");
            e.printStackTrace();  // Log the exception to application logs
        } finally {
            try {
                if (pst != null) {
                    pst.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}