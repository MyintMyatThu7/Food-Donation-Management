import java.sql.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

/**
 * Servlet implementation class updateServlet
 */
public class updateEmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
    PreparedStatement pst;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public updateEmployeeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		String oldmodel=request.getParameter("oldmodel");
		String Brand=request.getParameter("Brand");
		String Model=request.getParameter("Model");
		String Color=request.getParameter("Color");
		int Price=Integer.parseInt(request.getParameter("Price"));
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.print("Driver Ok");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/database","root","root");
			System.out.print("Connection OK");
			String s="update phone set brand=?,model=?,color=?,price=? where model=?";
			pst=con.prepareStatement(s);
			pst.setString(1, Brand);
			pst.setString(2, Model);
			pst.setString(3, Color);
			pst.setInt(4, Price);
			pst.setString(5, oldmodel);
			pst.executeUpdate();
			//pst.close();
			//icon.close();
			
		}
			catch(Exception e) {
				out.print("Something Error");
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
