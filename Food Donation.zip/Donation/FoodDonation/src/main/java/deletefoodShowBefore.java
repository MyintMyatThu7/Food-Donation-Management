

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * Servlet implementation class deletefoodShowBefore
 */
public class deletefoodShowBefore extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
    PreparedStatement pst;
    Statement st;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public deletefoodShowBefore() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		HttpSession gr = request.getSession();
		String id[] = (String[])gr.getAttribute("gg");
		
		HttpSession gg=request.getSession();
		String userid= (String) gg.getAttribute("useridd");
		//gr.setAttribute("ko", id);
		String userName = request.getParameter("userName");
		String userPhone = request.getParameter("userPhone");
		String userAddress = request.getParameter("userAddress");
		
		
        
      
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.print("Driver Ok");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/database3", "root", "root");
			System.out.print("Connection Ok");
		
		
		String s = "insert into deliveryuser values(?,?,?,?,?,?,?,?,?)";
    	try(PreparedStatement p = con.prepareStatement(s)) {
    		for(int i = 0; i < id.length; i++) {
    			st = con.createStatement();
    			String sql = "select * from foodshow where FoodID='"+ id[i]+"'";
    			ResultSet rs = st.executeQuery(sql);
    			
    			while(rs.next()) {
    				String foodID = rs.getString(1);
    				String foodName = rs.getString(2);
    				String foodQuantity = rs.getString(3);
    				String foodDate = rs.getString(4);
    				String donatorId = rs.getString(5);
    			
    				
//    				
    				p.setString(1, userid);  //column 1
         			p.setString(2, userName);
          			
          			p.setString(3, userPhone);
         			p.setString(4, userAddress);
          			p.setString(5, foodID);
          			p.setString(6, foodName);
          			p.setString(7, foodQuantity);
          			p.setString(8, foodDate);
          			p.setString(9, donatorId);
          			
          			p.executeUpdate();
    			}
    		}
    		request.getRequestDispatcher("deletefoodShowBefore2").forward(request, response);
    	}catch(Exception  e) {
    		out.print("customerFood error");
    	}
    	
    	
    	
    	
    	
	}catch(Exception e) {
		out.print("Good Night");
	}
	
}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
