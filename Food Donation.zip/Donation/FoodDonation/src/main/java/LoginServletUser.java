

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import org.apache.catalina.connector.Connector;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServletUser

extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
	PreparedStatement pst;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServletUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String userID = "UID";
		String EmailUser = request.getParameter("name");
		
		String Phone = request.getParameter("phone");
		String Address = request.getParameter("address");
	
		int cus_id = 1;
		Cookie ck[] = request.getCookies();
		
		if(ck != null) {
			
			for(Cookie c:ck) {
				
				if(c.getName().equals("student")) {
					cus_id = Integer.parseInt(c.getValue()) + 1;
				}
			}
		Cookie cus = new Cookie("student",Integer.toString(cus_id));
		cus.setMaxAge(36000);
		response.addCookie(cus);
		userID += cus_id;
		}
		
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");//Class.forName() method to load the MySQL JDBC driver class, which is com.mysql.jdbc.Driver. Loading the driver is necessary before establishing a database connection using JDBC.
			
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/database3", "root", "root");
			
			
			String s = "insert into user values(?,?,?,?)";
			pst = con.prepareStatement(s);
			
			pst.setString(1, userID);  //column 1
			pst.setString(2, EmailUser);
			
			pst.setString(3, Phone);
			pst.setString(4,Address);
			
			out.print("<html><body><script>alert('Successfully');</script></body></html>");
			pst.executeUpdate(); //to add and update data
			
			pst.close();
			con.close();
			request.getRequestDispatcher("UserLogin.jsp").forward(request, response);
			out.print("hello");
		}catch(Exception e) {
			
			out.print("Something error");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
