import java.sql.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class deleteServlet
 */
public class deleteEmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
    PreparedStatement pst;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public deleteEmployeeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		String delmepID=request.getParameter("name");
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.print("Driver Ok");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/database3","root","root");
			System.out.print("Connection OK");
			String s="delete from employee where employee_iD=?";
			pst=con.prepareStatement(s);
			pst.setString(1, delmepID);//same yin delete
			pst.executeUpdate();
			
			request.getRequestDispatcher("AdminMain.jsp").include(request, response);
			out.print("<html><body><script>alert('Delete Employer Succefully!!')</script></body></html>");
		}
		catch(Exception e) {
			request.getRequestDispatcher("AdminMain.jsp").include(request, response);
			out.print("<html><body><script>alert('Something Error.Please Try again!')</script></body></html>");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
