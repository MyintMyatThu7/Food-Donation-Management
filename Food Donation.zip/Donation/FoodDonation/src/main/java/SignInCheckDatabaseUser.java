

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * Servlet implementation class LoginCheckDataBaseServlet
 */
public class SignInCheckDatabaseUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	boolean result = false;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SignInCheckDatabaseUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String name = request.getParameter("name");
		String phone = request.getParameter("ph");
		result = false;
		try {
			Class.forName("com.mysql.jdbc.Driver");//Class.forName() method to load the MySQL JDBC driver class, which is com.mysql.jdbc.Driver. Loading the driver is necessary before establishing a database connection using JDBC.
			System.out.print("Driver Ok");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/database3", "root", "root");
			System.out.print("Connection Ok");
			
		    String s = "select * from user where U_name='"+name+"' and U_phone='"+phone+"'";
		    pst = con.prepareStatement(s);
		    rs = pst.executeQuery();
		    while(rs.next()) {//to read step by step use next
		    	result = true;
		    	String userid = rs.getString("U_ID");
		    	HttpSession session = request.getSession(true);
		    	session.setAttribute("useridd", userid);
		    }
		    pst.close();
		    con.close();
		}catch(Exception e) {
			out.print(e);
		}
		if(result) {
			request.getRequestDispatcher("UserMain.jsp").forward(request, response);
		}else {
			request.getRequestDispatcher("UserLogin.jsp").include(request, response);
			out.print("<html><body><script>alert('Uncorrect password.Please Tty again!')</script></body></html>");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
