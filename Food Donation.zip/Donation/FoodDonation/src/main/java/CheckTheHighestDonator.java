import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

@WebServlet("/CheckTheHighestDonator")
public class CheckTheHighestDonator extends HttpServlet {
    private static final long serialVersionUID = 1L;
    Connection con;
    Statement st;

    public CheckTheHighestDonator() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.print("<html><head>");
        out.print("<style>table{margin-left: 670px;border:3px solid rgb(255, 155, 6);}</style>");
        out.print("</head><body></body></html>");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            //out.print("Driver loaded successfully");

            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/database3", "root", "root");
            //out.print("Connected to the database");

            st = con.createStatement();
            String checkData = "SELECT DonaterID, COUNT(*) AS cnt " +
                    "FROM foodmain " +
                    "GROUP BY DonaterID " +
                    "ORDER BY cnt DESC;";
            ResultSet rs = st.executeQuery(checkData);
            out.print("");
            out.println("<html><body><table border='1'>");
            out.println("<tr><th>DonatorID</th><th>FoodQuantity</th></tr>");
            while (rs.next()) {
                String donatorId = rs.getString("DonaterID");
                String count = rs.getString("cnt");
                out.println("<tr><td>" + donatorId + "</td><td>" + count + "</td></tr>");
            }
            out.println("</table></body></html>");

        } catch (Exception e) {
            out.print("Error: " + e.getMessage());
            e.printStackTrace(); // This is for debugging purposes, remove it in a production environment.
        } finally {
            try {
                if (st != null) {
                    st.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (Exception e) {
                out.print("Error while closing resources: " + e.getMessage());
                e.printStackTrace(); // This is for debugging purposes, remove it in a production environment.
            }
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}