

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

/**
 * Servlet implementation class chageUserTableDelete
 */
public class chageUserTableDelete extends HttpServlet {
	private static final long serialVersionUID = 1L;
    Connection con;
    PreparedStatement pst;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public chageUserTableDelete() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        HttpSession m = request.getSession();
        String idFood[] = (String[])m.getAttribute("idFood");
        
        try {
        	Class.forName("com.mysql.jdbc.Driver");
        	con = DriverManager.getConnection("jdbc:mysql://localhost:3306/database3", "root", "root");
        	
        	String deleteModel = "delete from deliveryuser where f_id=?";
        	pst = con.prepareStatement(deleteModel);
        	
        	for(int i = 0; i < idFood.length; i++) {
        		pst.setString(1, idFood[i]);
        		pst.executeUpdate();
        	}
        	 request.getRequestDispatcher("DonaterMain.jsp").forward(request, response);
        }catch(Exception e) {
        	out.print("Love You");
        }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
